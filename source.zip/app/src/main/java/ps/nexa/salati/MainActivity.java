package ps.nexa.salati;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE = "https://" + HOST + "/";
    private static final int REQ_LOC = 51, REQ_NOTIF = 52;

    private static WeakReference<MainActivity> live = new WeakReference<>(null);

    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean locSilent = false, locBusy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bars();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(dark() ? "#0A110F" : "#F2F5F2"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serve(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl(BASE + "index.html");
        live = new WeakReference<>(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Engine.screenOn = true;
        live = new WeakReference<>(this);
        new Thread(() -> {
            try { new Engine(this).refresh(false, false); } catch (Exception ignored) { }
        }).start();
        js("window.onResumeApp && onResumeApp()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Engine.screenOn = false;
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        bars();
        js("window.applyTheme && applyTheme()");
    }

    boolean dark() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void bars() {
        boolean d = dark();
        getWindow().setStatusBarColor(Color.parseColor(d ? "#0B2B24" : "#0F4F40"));
        getWindow().setNavigationBarColor(Color.parseColor(d ? "#121B18" : "#FFFFFF"));
        if (Build.VERSION.SDK_INT >= 26) {
            View v = getWindow().getDecorView();
            int f = v.getSystemUiVisibility();
            if (d) f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; else f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            v.setSystemUiVisibility(f);
        }
    }

    /** called from the receiver when something changed in the background */
    static void notifyChanged() {
        MainActivity a = live.get();
        if (a != null) a.js("window.onChanged && onChanged()");
    }

    private void js(String code) {
        main.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    /* ---------- serving assets ---------- */
    private WebResourceResponse serve(Uri u) {
        if (u == null || !HOST.equals(u.getHost())) return null;
        String path = u.getPath() == null ? "/" : u.getPath();
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        try {
            String file = path.startsWith("/") ? path.substring(1) : path;
            if (file.isEmpty()) file = "index.html";
            InputStream in = getAssets().open(file);
            String m = mime(file);
            return new WebResourceResponse(m, m.startsWith("text") || m.contains("javascript") || m.contains("json") ? "utf-8" : null,
                    200, "OK", headers, in);
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers,
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mime(String file) {
        if (file.endsWith(".html")) return "text/html";
        if (file.endsWith(".js")) return "application/javascript";
        if (file.endsWith(".json")) return "application/json";
        if (file.endsWith(".css")) return "text/css";
        if (file.endsWith(".ttf")) return "font/ttf";
        if (file.endsWith(".svg")) return "image/svg+xml";
        String ext = MimeTypeMap.getFileExtensionFromUrl(file);
        String m = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? "application/octet-stream" : m;
    }

    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
    }

    private boolean tryStart(Intent i) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true; } catch (Exception e) { return false; }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.appBack && window.appBack()) ? 'y' : 'n'", value -> {
            if (value == null || !value.contains("y")) super.onBackPressed();
        });
    }

    /* ---------- location ---------- */
    private boolean hasLoc() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean locOn() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
            return lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) { return false; }
    }

    private void locate(boolean silent) {
        if (locBusy) return;
        locSilent = silent;
        if (!hasLoc()) {
            if (silent) return;
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
            return;
        }
        if (!locOn()) { if (!silent) locDone(false, "off", null); return; }
        locBusy = true;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        try {
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
        } catch (SecurityException ignored) { }
        if (best != null && System.currentTimeMillis() - best.getTime() < 15 * 60000L) { gotLocation(best); return; }

        final Location fallback = best;
        final boolean[] done = {false};
        final LocationListener[] holder = new LocationListener[1];
        LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                if (done[0]) return;
                done[0] = true;
                try { lm.removeUpdates(this); } catch (Exception ignored) { }
                gotLocation(l);
            }
            @Override public void onStatusChanged(String p, int s, Bundle b) { }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
        };
        holder[0] = ll;
        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, ll, Looper.getMainLooper());
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, ll, Looper.getMainLooper());
        } catch (SecurityException e) {
            locBusy = false;
            locDone(false, "perm", null);
            return;
        }
        main.postDelayed(() -> {
            if (done[0]) return;
            done[0] = true;
            try { lm.removeUpdates(holder[0]); } catch (Exception ignored) { }
            if (fallback != null) gotLocation(fallback);
            else { locBusy = false; locDone(false, "fail", null); }
        }, 30000);
    }

    private void gotLocation(Location l) {
        final double lat = l.getLatitude(), lng = l.getLongitude();
        new Thread(() -> {
            try {
                Store st = new Store(this);
                JSONObject old = st.loc();
                TimeZone.setDefault(null);
                String tz = TimeZone.getDefault().getID();
                // a silent refresh only matters if we actually moved or the time zone changed
                if (locSilent && "auto".equals(old.optString("mode"))
                        && dist(lat, lng, old.optDouble("lat"), old.optDouble("lng")) < 5
                        && tz.equals(old.optString("tz"))) {
                    locBusy = false;
                    return;
                }
                String name = null, cc = null;
                try {
                    if (Geocoder.isPresent()) {
                        List<Address> r = new Geocoder(this, new Locale("ar")).getFromLocation(lat, lng, 1);
                        if (r != null && !r.isEmpty()) {
                            Address a = r.get(0);
                            name = a.getLocality();
                            if (name == null) name = a.getSubAdminArea();
                            if (name == null) name = a.getAdminArea();
                            cc = a.getCountryCode();
                        }
                    }
                } catch (Exception ignored) { }
                JSONObject near = nearestCity(lat, lng);
                if (near != null) {
                    if (cc == null) cc = near.optString("cc");
                    if (name == null) name = near.optDouble("km") < 30 ? near.optString("name") : "قرب " + near.optString("name");
                }
                if (name == null) name = "موقعك";
                JSONObject loc = new JSONObject()
                        .put("name", name).put("cc", cc == null ? "" : cc)
                        .put("lat", lat).put("lng", lng).put("tz", tz).put("mode", "auto").put("at", System.currentTimeMillis());
                st.put("loc", loc);
                new Engine(this).refresh(false, true);
                locBusy = false;
                locDone(true, null, name);
            } catch (Exception e) {
                locBusy = false;
                locDone(false, "fail", null);
            }
        }).start();
    }

    private void locDone(boolean ok, String err, String name) {
        try {
            JSONObject o = new JSONObject().put("ok", ok).put("silent", locSilent);
            if (err != null) o.put("err", err);
            if (name != null) o.put("name", name);
            js("window.onLoc && onLoc(" + o + ")");
        } catch (Exception ignored) { }
    }

    static double dist(double a1, double o1, double a2, double o2) {
        double r = 6371, dLat = Math.toRadians(a2 - a1), dLon = Math.toRadians(o2 - o1);
        double h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(a1)) * Math.cos(Math.toRadians(a2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * r * Math.asin(Math.sqrt(h));
    }

    private JSONObject nearestCity(double lat, double lng) {
        try (InputStream in = getAssets().open("cities.json")) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONArray arr = new JSONObject(bo.toString("UTF-8")).getJSONArray("cities");
            JSONArray best = null; double bd = 1e9;
            for (int i = 0; i < arr.length(); i++) {
                JSONArray c = arr.getJSONArray(i);
                double d = dist(lat, lng, c.getDouble(2), c.getDouble(3));
                if (d < bd) { bd = d; best = c; }
            }
            if (best == null) return null;
            return new JSONObject().put("name", best.getString(0)).put("cc", best.getString(1)).put("km", bd);
        } catch (Exception e) { return null; }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOC) {
            if (hasLoc()) locate(false);
            else locDone(false, shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION) ? "denied" : "blocked", null);
        } else if (requestCode == REQ_NOTIF) {
            js("window.onChanged && onChanged()");
        }
    }

    /* ---------- permissions status ---------- */
    private JSONObject perms() {
        JSONObject o = new JSONObject();
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            o.put("notif", nm.areNotificationsEnabled());
            boolean exact = true;
            if (Build.VERSION.SDK_INT >= 31) exact = ((AlarmManager) getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();
            o.put("exact", exact);
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            o.put("battery", pm.isIgnoringBatteryOptimizations(getPackageName()));
            o.put("loc", hasLoc()).put("locOn", locOn());
            o.put("xiaomi", Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase(Locale.US).matches(".*(xiaomi|redmi|poco).*"));
            o.put("sdk", Build.VERSION.SDK_INT);
        } catch (Exception ignored) { }
        return o;
    }

    /* ---------- bridge ---------- */
    public class Bridge {
        private String state() { return new Engine(MainActivity.this).stateJson(System.currentTimeMillis()).toString(); }

        @JavascriptInterface public boolean isDark() { return dark(); }

        @JavascriptInterface public String getState() { return state(); }

        @JavascriptInterface public String cities() {
            try (InputStream in = getAssets().open("cities.json")) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public String mark(String day, String k, boolean done) {
            new Engine(MainActivity.this).mark(day, k, done, System.currentTimeMillis());
            new Engine(MainActivity.this).refresh(false, true);
            return state();
        }

        @JavascriptInterface public String qada(String k, int delta) {
            new Engine(MainActivity.this).qadaAdd(k, delta);
            return state();
        }

        @JavascriptInterface public String setSettings(String json) {
            try {
                Store st = new Store(MainActivity.this);
                JSONObject s = st.settings();
                JSONObject in = new JSONObject(json);
                Iterator<String> it = in.keys();
                while (it.hasNext()) { String k = it.next(); s.put(k, in.get(k)); }
                st.put("set", s);
                if (in.has("remind") || in.has("after") || in.has("every") || in.has("quiet") || in.has("adhan") || in.has("off") || in.has("method") || in.has("asr"))
                    st.putLong("lastFire", 0);
                new Engine(MainActivity.this).refresh(false, true);
            } catch (Exception ignored) { }
            return state();
        }

        @JavascriptInterface public String setCity(String json) {
            try {
                JSONObject c = new JSONObject(json);
                c.put("mode", "city").put("at", System.currentTimeMillis());
                new Store(MainActivity.this).put("loc", c);
                new Engine(MainActivity.this).refresh(false, true);
            } catch (Exception ignored) { }
            return state();
        }

        @JavascriptInterface public void locate(boolean silent) { main.post(() -> MainActivity.this.locate(silent)); }

        @JavascriptInterface public String perms() { return MainActivity.this.perms().toString(); }

        @JavascriptInterface public void askNotif() {
            main.post(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && !"asked".equals(new Store(MainActivity.this).getStr("notifAsked", ""))) {
                    new Store(MainActivity.this).putStr("notifAsked", "asked");
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                } else openNotif();
            });
        }

        @JavascriptInterface public void openNotif() {
            Intent i = new Intent();
            if (Build.VERSION.SDK_INT >= 26) {
                i.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            } else {
                i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + getPackageName()));
            }
            if (!tryStart(i)) openAppSettings();
        }

        @JavascriptInterface public void openExact() {
            if (Build.VERSION.SDK_INT >= 31 && tryStart(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())))) return;
            openAppSettings();
        }

        @JavascriptInterface public void openBattery() {
            if (tryStart(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())))) return;
            if (tryStart(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) return;
            openAppSettings();
        }

        @JavascriptInterface public void openAutostart() {
            Intent i = new Intent().setComponent(new ComponentName("com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            if (tryStart(i)) return;
            openAppSettings();
        }

        @JavascriptInterface public void openLocSettings() {
            if (!tryStart(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))) openAppSettings();
        }

        @JavascriptInterface public void openAppSettings() {
            tryStart(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void test() { new Engine(MainActivity.this).test(); }

        @JavascriptInterface public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public void openUrl(String url) { openExternal(url); }

        @JavascriptInterface public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
        }
    }
}
